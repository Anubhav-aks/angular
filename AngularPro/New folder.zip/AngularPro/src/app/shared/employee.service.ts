import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { Employee } from './employee.model'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  selectedEmployee: Employee;
  employees: Employee[];
  readonly baseUrl = 'http://localhost:3000/employees';
  constructor(public http: HttpClient) { }
  postEmployee(emp: Employee): Observable<any> {

    return this.http.post(this.baseUrl, emp);

  }
  getEmployeeList() {
    return this.http.get(this.baseUrl)
  }
  putEmployee(value): Observable<any> {
    return this.http.put(this.baseUrl, `/${value._id}`, value)
  }

}
