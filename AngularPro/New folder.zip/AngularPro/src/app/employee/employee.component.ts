import { Component, OnInit } from '@angular/core';

import { EmployeeService } from '../shared/employee.service';
import { Employee } from '../shared/employee.model'

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})
export class EmployeeComponent implements OnInit {

  constructor(public employeeService: EmployeeService) { }
 public newForm:any;
  ngOnInit() {
    this.resetForm();
    this.refreshPage();
  }
  resetForm(form?) {
    if (form) {
      form.resetForm()
      this.employeeService.selectedEmployee = {
        _id: "",
        name: "",
        position: "",
        office: "",
        salary: null
      }
    }

  }
  onSubmit(form) {
    if(form.value._id==""){
    this.employeeService.postEmployee(form.value).subscribe((res) => {
      this.newForm=form;
      this.resetForm(form);
      this.refreshPage();
      

    });}
    else{
     this.employeeService.putEmployee(form.value).subscribe((res)=>{
      this.newForm=form;
      this.resetForm(form);
      this.refreshPage();
     })
    }
  }
  refreshPage(){
    this.employeeService.getEmployeeList().subscribe((res:Employee[])=>{

      this.employeeService.employees=res ;
    })
  }
  onEdit(emp1 :Employee){
   this.employeeService.selectedEmployee= emp1;
   
  }
  onDelete(value){

  }
}

